package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Pages_01_Login_Page {
WebDriver driver;
       public Pages_01_Login_Page(WebDriver driver)
       {
    	   this.driver = driver;
       }
       
       public WebElement Elemental_Selenium(){
    	   return driver.findElement(By.xpath("//a[@target=\"_blank\"]"));
    	   
       }
       public WebElement flash_error(){
    	   return driver.findElement(By.id("flash"));
    	   
       }
       public WebElement Login_Btn(){
    	   return driver.findElement(By.cssSelector("button[type=\"submit\"]"));
    	   
       }
       
       public WebElement UserName_txt(){
    	   return driver.findElement(By.xpath("//input[@name=\"username\"]"));
       }
       
       public WebElement PWD_txt(){
    	   return driver.findElement(By.xpath("//input[@name=\"password\"]"));
       }
       public WebElement flash_Msg (){
    	   return driver.findElement(By.xpath("//div[@class=\"flash success\"]"));
       }
	
}
