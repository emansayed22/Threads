package Test_Cases;

import org.testng.annotations.Test;

import Pages.Pages_01_Login_Page;
import static org.testng.Assert.assertTrue;


public class T_01_Login_Test_Cases extends TestBase{
	//WebDriver driver;

	//	@BeforeTest
	//	public void beforeTest() {
	//		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	//		System.setProperty("webdriver.chrome.driver", chromePath);
	//		driver = new ChromeDriver();
	//		driver.manage().window().maximize();
	//		//	driver.navigate().to("https://the-internet.herokuapp.com/login");
	//		driver.get("https://the-internet.herokuapp.com/login");
	//	}
	@Test
	public void Invalid_Username() {

		Pages_01_Login_Page p01 = new  Pages_01_Login_Page(driver);
		p01.UserName_txt().sendKeys("userName");
		//enter invalid user name
		//enter invalid password
		p01.PWD_txt().sendKeys("passWord");
		//click login btn
		p01.Login_Btn().click();
		System.out.println(p01.flash_error().getText());	
		// assert error msg
		assertTrue(p01.flash_error().getText().contains("Your username is invalid!"));



	}

	@Test
	public void Valid_Username() {
		Pages_01_Login_Page p01 = new  Pages_01_Login_Page(driver);
		// clear username field
		p01.UserName_txt().clear();
		//enter valid username
		p01.UserName_txt().sendKeys("tomsmith ");
		//clear password
		p01.PWD_txt().clear();
		//	driver.findElement(By.id("")).clear();
		//enter valid password 
		p01.PWD_txt().sendKeys("SuperSecretPassword!");
		p01.PWD_txt().submit();

		System.out.println(p01.flash_Msg().getText());	
		assertTrue(p01.flash_Msg().getText().contains("You logged into a secure area!"));
		// assert 
		//	driver.findElement(By.id("")).sendKeys(Keys.ENTER);
		//	driver.findElement(By.id("")).submit();

	}

	//	@AfterTest
	//	public void afterTest() {
	//		driver.quit();
	//	}

}
